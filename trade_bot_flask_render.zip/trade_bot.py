import os, io, datetime
from flask import Flask, Response
import yfinance as yf
import numpy as np
import pandas as pd
from ta.momentum import RSIIndicator
from ta.trend import SMAIndicator, EMAIndicator
import xgboost as xgb
import vectorbt as vbt

log_stream = io.StringIO()

def log(msg):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{timestamp}] {msg}\n"
    print(line, end="")
    log_stream.write(line)

def run_backtest():
    log("Fetching data...")
    df = yf.download("SPY", start="2016-01-01", progress=False)
    df['return'] = df['Adj Close'].pct_change()
    df.dropna(inplace=True)

    df['sma20'] = SMAIndicator(df['Adj Close'], 20).sma_indicator()
    df['rsi14'] = RSIIndicator(df['Adj Close'], 14).rsi()
    df.dropna(inplace=True)
    df['target'] = (df['return'].shift(-1) > 0).astype(int)

    features = ['sma20','rsi14']
    X = df[features]
    y = df['target']

    split = int(len(df) * 0.8)
    model = xgb.XGBClassifier(use_label_encoder=False, eval_metric='logloss')
    model.fit(X.iloc[:split], y.iloc[:split])

    preds = model.predict_proba(X)[:,1]
    df['pred'] = preds
    log("Backtest complete.")
    return df

df = run_backtest()

app = Flask(__name__)

@app.route("/")
def home():
    return "✅ Trade Bot is running. Visit /logs for output."

@app.route("/logs")
def logs():
    return Response(log_stream.getvalue(), mimetype="text/plain")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=10000)
